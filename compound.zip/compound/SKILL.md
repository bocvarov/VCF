---
name: compound
description: Capture durable learnings from a completed work session into a structured, searchable knowledge store (docs/solutions/ plus concise updates to CLAUDE.md or AGENTS.md), so every future session starts smarter. Use after finishing a task, fixing a bug, completing an agent run, or whenever the user wants to save lessons, document a solved problem, or review what was learned. Trigger on phrases like "compound this session", "save what we learned", "document this fix", "zkompounduj session", "ulož ponaučení", "zdokumentuj řešení". Never run automatically — always ask for approval first.
license: MIT (see LICENSE.txt)
metadata:
  version: "1.0"
  language: instructions in English, works with users in any language
compatibility: Works in Claude Code, Claude Cowork, and Claude.ai with file access. No external dependencies.
---

# Compound

Turn one finished piece of work into knowledge that makes the next piece of work easier. Each documented solution compounds: the first time a problem is solved takes research; once documented, the next occurrence takes minutes.

## Core rules (read first)

1. **Never compound automatically.** After a meaningful session, ask: *"Do you want to compound this session?"* (match the user's language, e.g. "Chceš tuto session zkompoundovat?"). Wait for approval before writing anything.
2. **One learning, one small change.** Prefer several small, specific documents over one sprawling one.
3. **Evidence or it didn't happen.** Every saved learning must cite concrete evidence from the session: a tool result, a diff, a test run, an error message, or an explicit user correction. If you cannot point to evidence, do not save it.
4. **Not everything deserves to be saved.** Filtering out noise is as valuable as capturing signal. A knowledge store full of one-off details stops being read.

## Workflow

### Step 1 — Review the session

Look back over the completed session and collect candidate learnings. Sort every candidate into exactly one of these six buckets:

1. **Durable lessons** — insights that apply to future work in this project or beyond (root causes, working fixes, patterns, gotchas).
2. **Project facts** — stable, project-specific context (naming conventions, environment quirks, key file locations).
3. **Preferences** — personal or team preferences discovered during the session (tone, formatting, review style, approval boundaries).
4. **Tool and workflow improvements** — a better command, script, prompt structure, or process discovered along the way.
5. **Mistakes that must NOT become rules** — one-time errors caused by unusual circumstances. Record the reasoning for excluding them, then discard.
6. **One-off details** — timestamps, throwaway values, session-specific noise. Discard without documentation.

Buckets 1–4 are candidates for saving. Buckets 5–6 are explicitly not saved — but list them in the final report so the user sees the filtering happened.

### Step 2 — Classify each learning by track

Read `references/schema.md` for the full contract. In short:

- **Bug track** — a defect that was diagnosed and fixed (build error, test failure, runtime error, performance issue, security issue, UI bug, integration issue, logic error).
- **Knowledge track** — guidance, patterns, decisions, conventions, and workflow improvements (best practice, architecture pattern, tooling decision, convention, documentation gap).

The track determines which template sections to use in Step 4.

### Step 3 — Check for overlap before writing

Search the existing knowledge store (`docs/solutions/` by default) for related documents before creating anything new. Use filename and content search on keywords from the problem: module names, error messages, technical terms.

Assess overlap across five dimensions: problem statement, root cause, solution approach, referenced files, prevention rules.

| Overlap | Action |
|---|---|
| **High** (4–5 dimensions match) | **Update the existing doc** — add fresher context, new examples, updated references. Add `last_updated: YYYY-MM-DD` to its frontmatter. Do not create a duplicate. |
| **Moderate** (2–3 match) | Create the new doc, and cross-link both documents in a "Related" section. |
| **Low** (0–1 match) | Create the new doc normally. |

Why update instead of duplicate: two documents describing the same problem inevitably drift apart, and future readers cannot tell which one is current.

### Step 4 — Write the documentation

For each learning worth saving:

1. Read `assets/learning-template.md` and use the section structure for the matching track.
2. Fill in YAML frontmatter per `references/schema.md`. Quote any YAML scalar containing `: ` or starting with special characters, so parsers do not silently truncate or misread it.
3. Choose the target directory `docs/solutions/<category>/` based on the problem type (category mapping is in the schema reference). Create the directory if needed.
4. Name the file with a short descriptive slug, e.g. `docs/solutions/test-failures/flaky-webhook-timeout.md`. No date in the filename — the `date:` frontmatter field is canonical.
5. Write the file. Keep it focused: a future agent should be able to read it in under a minute and act on it.

### Step 5 — Route non-document learnings

Not every learning belongs in `docs/solutions/`:

- **Concise always-on rules** (bucket 2 and 3 items short enough for one line) → propose a small addition to the project instruction file (`CLAUDE.md` or `AGENTS.md`). Show the exact diff and ask before applying. Only rules that genuinely belong in *every* session qualify — instruction files bloat quickly and lose authority when they do.
- **Repeatable procedures** (bucket 4 items with multiple steps) → propose creating or updating a dedicated skill instead of pasting the procedure into the instruction file.
- **Everything else** stays in `docs/solutions/`.

### Step 6 — Discoverability check

Knowledge only compounds when future agents can find it. Check whether the project's instruction file (`CLAUDE.md` or `AGENTS.md`) mentions `docs/solutions/` as a place to look for prior solutions. If not, propose the smallest possible addition — one line in an existing list where it fits, a two-line section only when nothing else does. Match the file's existing tone and density. Ask for consent before applying.

### Step 7 — Report back

End every compound run with this exact structure:

```
## Compound report
### Saved
- [file path] — [one-line summary + the evidence it cites]
### Updated
- [file path] — [what changed and why]
### Deliberately not saved
- [item] — [which bucket, and why it was excluded]
### How the next run improves
- [1–3 concrete ways future sessions benefit from what was saved]
```

## Lightweight mode

When the session was short, context is nearly full, or the user asks for a quick version: skip the overlap search (Step 3) and discoverability check (Step 6), document the single most valuable learning using the template, and produce the report. Say explicitly that duplicate detection was skipped.

## What NOT to do

- Do not save a learning without evidence from this session.
- Do not turn a one-off mistake into a general rule.
- Do not paste long procedures into CLAUDE.md/AGENTS.md — route them to skills.
- Do not create a second document for a problem that already has one — update it.
- Do not run this workflow without the user's explicit approval.
