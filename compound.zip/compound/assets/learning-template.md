# Learning Templates

Choose the template matching the track (see `references/schema.md`).

---

## Bug track template

Use for defects that were diagnosed and fixed.

```markdown
---
title: "[Clear problem title]"
date: YYYY-MM-DD
category: [docs/solutions subdirectory]
module: "[Module or area affected]"
problem_type: [enum from schema]
symptoms:
  - "[Observable symptom or error message]"
root_cause: "[One-line root cause]"
severity: [low | medium | high | critical]
tags: [keyword-one, keyword-two]
---

# [Clear problem title]

## Problem
[1–2 sentences: what broke and its user-visible impact.]

## Symptoms
- [Observable symptom, exact error message when possible]

## What didn't work
- [Attempted fix and why it failed — this saves the most future time]

## Solution
[The fix that worked. Include code before/after when useful.]

## Why this works
[Root cause explanation and why the fix addresses it, not just the symptom.]

## Prevention
- [Concrete practice, test, or guardrail that stops recurrence]

## Related
- [Links to related docs in docs/solutions/, issues, or PRs — omit if none]
```

---

## Knowledge track template

Use for practices, patterns, decisions, and workflow improvements.

```markdown
---
title: "[Clear guidance title]"
date: YYYY-MM-DD
category: [docs/solutions subdirectory]
module: "[Module or area affected]"
problem_type: [enum from schema]
applies_when:
  - "[Situation where this guidance applies]"
tags: [keyword-one, keyword-two]
---

# [Clear guidance title]

## Context
[What situation, gap, or friction prompted this guidance.]

## Guidance
[The practice, pattern, or recommendation. Include examples when useful.]

## Why this matters
[Impact of following — or ignoring — this guidance.]

## When to apply
- [Condition or situation]

## Examples
[Concrete before/after or usage example.]

## Related
- [Links to related docs — omit if none]
```
