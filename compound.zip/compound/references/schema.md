# Frontmatter schema for docs/solutions/

The canonical contract for every learning document. Two tracks, chosen by `problem_type`.

## Tracks and problem types

**Bug track** — defects diagnosed and fixed:
`build_error`, `test_failure`, `runtime_error`, `performance_issue`, `database_issue`, `security_issue`, `ui_bug`, `integration_issue`, `logic_error`

**Knowledge track** — guidance and decisions:
`best_practice`, `architecture_pattern`, `design_pattern`, `tooling_decision`, `convention`, `workflow_issue`, `developer_experience`, `documentation_gap`

Prefer the narrowest applicable value; `best_practice` is the fallback when nothing narrower fits.

## Category mapping (problem_type → directory)

| problem_type | docs/solutions/ subdirectory |
|---|---|
| build_error | build-errors/ |
| test_failure | test-failures/ |
| runtime_error | runtime-errors/ |
| performance_issue | performance-issues/ |
| database_issue | database-issues/ |
| security_issue | security-issues/ |
| ui_bug | ui-bugs/ |
| integration_issue | integration-issues/ |
| logic_error | logic-errors/ |
| best_practice | best-practices/ |
| architecture_pattern | architecture-patterns/ |
| design_pattern | design-patterns/ |
| tooling_decision | tooling-decisions/ |
| convention | conventions/ |
| workflow_issue | workflow-issues/ |
| developer_experience | developer-experience/ |
| documentation_gap | documentation-gaps/ |

## Required fields (both tracks)

| Field | Type | Notes |
|---|---|---|
| `title` | string | Clear, searchable problem or guidance title |
| `date` | YYYY-MM-DD | Date documented; canonical creation date (never in the filename) |
| `category` | string | Subdirectory from the mapping above |
| `module` | string | Module or area affected |
| `problem_type` | enum | Determines the track |
| `tags` | list | 2–6 lowercase keywords a future agent might search for |

## Track-specific fields

| Field | Bug track | Knowledge track |
|---|---|---|
| `symptoms` | required (list) | optional |
| `root_cause` | required (string) | optional |
| `severity` | required (`low`/`medium`/`high`/`critical`) | omit |
| `applies_when` | omit | required (list) |
| `last_updated` | add when updating an existing doc | add when updating an existing doc |

## YAML safety rules

Silent corruption is worse than a validation error. Always:

- Wrap any scalar containing `: ` (colon + space) in double quotes — otherwise YAML parses it as a nested mapping.
- Wrap any scalar containing ` #` in double quotes — otherwise everything after `#` is silently dropped as a comment.
- Wrap list items starting with `[ ] { } * & ! | > % @ ?` or a backtick in double quotes.
- Keep the `---` delimiter lines exact: three hyphens, nothing else on the line.

## Quick self-check before writing

1. Does the frontmatter parse? (Mentally walk each line, or run it through a YAML parser if one is available.)
2. Is `problem_type` a valid enum value and does `category` match the mapping?
3. Does every list item that needs quoting have quotes?
4. Is there at least one tag a future agent would plausibly search for?
